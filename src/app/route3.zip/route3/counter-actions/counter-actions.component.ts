import { Component, OnInit, Output,EventEmitter, Input,  } from '@angular/core';
import { TimerObject } from 'src/models/timerObject';

@Component({
  selector: 'app-counter-actions',
  templateUrl: './counter-actions.component.html',
  styleUrls: ['./counter-actions.component.css']
})
export class CounterActionsComponent implements OnInit {
  @Input() pausedCounterValue:any=0;
  @Output() counterOutput:any  = new EventEmitter<TimerObject>(); //ask
  outputObject : TimerObject ;
  counter1: number = 0;
  startCheckFlag: boolean = false;
  constructor() { 
    this.outputObject = new TimerObject(this.counter1,'',new Date());
    console.log(this.outputObject, "obj to be sent")
  }

  ngOnInit(): void {
  }
  ngAfterViewInit(): void{
    console.log("counter1",this.counter1);
  }
  ngOnChanges(): void {

    console.log("this from paused counter"+this.pausedCounterValue);

    this.counter1=this.pausedCounterValue

 }
  startorpause(){
    this.startCheckFlag = !this.startCheckFlag;
    if (this.startCheckFlag){
      this.outputObject.actionType = "Start";

    }else{
      this.outputObject.actionType = "Pause";
      // console.log("2nd comp pause",this.pauseData)

    }
    this.outputObject.timestamping = new Date();
    this.outputObject.counterValue = this.counter1;
    this.outputObject = Object.assign({}, this.outputObject); // changing obj reference for ngOnChanges

    this.counterOutput.emit(this.outputObject);  
  }
  resetvalues(){
    console.log("reset----",this.outputObject);
    this.counter1 = 0;
    this.outputObject.actionType = "Reset";
    this.outputObject.counterValue = this.counter1;
    this.outputObject = Object.assign({}, this.outputObject); // changing obj reference for ngOnChanges
    console.log("reset--after--",this.outputObject);

    this.counterOutput.emit(this.outputObject);  

  }
}

import { Component, Input, OnInit } from '@angular/core';
import { DataService } from 'src/app/data.service';
import { loggerObject } from 'src/models/loggerObject';

@Component({
  selector: 'app-counter-action-logger',
  templateUrl: './counter-action-logger.component.html',
  styleUrls: ['./counter-action-logger.component.css']
})
export class CounterActionLoggerComponent implements OnInit {
  counterValue: any;
  pausedCounterValue : number = 0;
  requiredData : loggerObject[] = [];
  // demoObj: loggerObject = {actionType:'', timeStamping: 0}

  constructor(private dataService:DataService) { }

  ngOnInit(): void {
    console.log(this.counterValue,"counterValue");
    console.log("PausedCounterValue",this.pausedCounterValue);
      this.dataEnhancer();
  }

  ngOnChanges(): void{
  }
  dataEnhancer(): void{
    var demoObj: loggerObject = {actionType:'', timeStamping: 0}


    this.dataService.subject1.subscribe(data=>{
      this.counterValue=data;
      console.log("this.countervalue from logger",this.counterValue.actionType)
      if(this.counterValue.actionType == "Start"){
        demoObj.actionType = "Started";
        demoObj.timeStamping = Number(this.counterValue.counterValue);

    }
    else if(this.counterValue.actionType == "Pause"){
      demoObj.actionType = "Paused";
      this.dataService.pausedValue.subscribe(data=>{
        this.pausedCounterValue=data;
        demoObj.timeStamping = this.pausedCounterValue;
      })


     

    }
    this.requiredData.push(demoObj);
    console.log("logger data", this.requiredData)
    if(this.counterValue.actionType == "Reset"){
      this.requiredData = [];
    }
  })
     
  
  }

}
